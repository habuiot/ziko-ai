(function(){
"use strict";
var count=0,seen={},lastError="";
function safe(s){return String(s===undefined?"":s).replace(/[0-9]{5,}/g,"[number]").replace(/[^A-Za-z0-9 .:_/()[\]-]/g," ").slice(0,125);}
window.__zkPadDiag=function(event,source,detail,line){
 if(count>18)return;
 event=safe(event);source=safe(source);detail=safe(detail);line=Number(line)||0;
 var key=event+"|"+source+"|"+detail;
 if(seen[key])return;seen[key]=true;count++;
 var report={event:event,source:source,detail:detail,line:line,hasCustomElements:!!window.customElements,thermostatRegistered:!!(window.customElements&&window.customElements.get&&window.customElements.get("ziko-kiosk-thermostat")),lightsRegistered:!!(window.customElements&&window.customElements.get&&window.customElements.get("ziko-kiosk-lights"))};
 try{
 var x=new XMLHttpRequest();x.open("POST","/api/padcopy/diag",true);x.setRequestHeader("X-ZIKO-Request","1");x.setRequestHeader("Content-Type","application/json");x.send(JSON.stringify(report));
 }catch(e){}
};
window.addEventListener("error",function(ev){
 var target=ev&&ev.target||null;
 if(target&&target.tagName==="SCRIPT"){window.__zkPadDiag("script-failed",target.src.split("/").pop(),"",0);return;}
 var src=String(ev&&ev.filename||"").split("/").pop();
 window.__zkPadDiag("js-error",src,String(ev&&ev.message||"").slice(0,125),Number(ev&&ev.lineno)||0);
},true);
window.setTimeout(function(){window.__zkPadDiag("probe","10s","",0);},10000);
window.setTimeout(function(){window.__zkPadDiag("probe","25s","",0);},25000);
})();