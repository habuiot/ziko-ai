(function(w){
"use strict";
var missing=!w.Intl||typeof w.Intl.NumberFormat!=="function"||typeof w.Intl.DateTimeFormat!=="function"||(!!w.IntlPolyfill&&w.Intl===w.IntlPolyfill);
if(missing&&w.IntlPolyfill)w.Intl=w.IntlPolyfill;
if(!w.Intl||typeof w.Intl.NumberFormat!=="function"||typeof w.Intl.DateTimeFormat!=="function"){
 if(w.__zkPadDiag)w.__zkPadDiag("js-error","intl-compat","Intl polyfill missing",0);
 return;
}
if(!missing)return;
var BaseDateTimeFormat=w.Intl.DateTimeFormat;
function lastSundayUTC(year,month){
 var last=new Date(Date.UTC(year,month+1,0,1,0,0,0));
 return Date.UTC(year,month,last.getUTCDate()-last.getUTCDay(),1,0,0,0);
}
function budapestOffsetMs(instant){
 var t=instant.getTime(),year=instant.getUTCFullYear();
 return t>=lastSundayUTC(year,2)&&t<lastSundayUTC(year,9)?7200000:3600000;
}
function PadDateTimeFormat(locale,options){
 var opts=options||{};
 if(opts.timeZone!=="Europe/Budapest")return new BaseDateTimeFormat(locale,opts);
 var utc={};for(var k in opts){if(Object.prototype.hasOwnProperty.call(opts,k))utc[k]=opts[k];}
 utc.timeZone="UTC";
 var formatter=new BaseDateTimeFormat(locale,utc);
 return {
  format:function(value){
   var d=value===undefined?new Date():value instanceof Date?value:new Date(value);
   if(!isFinite(d.getTime()))return "—";
   return formatter.format(new Date(d.getTime()+budapestOffsetMs(d)));
  },
  resolvedOptions:function(){
   var out=formatter.resolvedOptions();
   out.timeZone="Europe/Budapest";
   return out;
  }
 };
}
PadDateTimeFormat.supportedLocalesOf=BaseDateTimeFormat.supportedLocalesOf;
w.Intl.DateTimeFormat=PadDateTimeFormat;
if(w.__zkPadDiag)w.__zkPadDiag("probe","intl-fix","Intl polyfill loaded",0);
})(window);