(function(){
"use strict";
var root=document.getElementById("ziko-pad-root");
var cover=document.getElementById("ziko-pad-pair");
var status=document.getElementById("ziko-pad-message");
var session=false,device=null,live=false,refreshing=false,started=false,route="";
var HA={states:{},connection:{connected:false}};
function elem(id){return document.getElementById(id);}
function message(s){status.textContent=s||"";}
function request(method,path,data,ok,fail){
 var xhr=new XMLHttpRequest(),done=false;
 try{
  xhr.open(method,path,true);xhr.timeout=16000;
  xhr.setRequestHeader("X-ZIKO-Request","1");
  if(data!==null)xhr.setRequestHeader("Content-Type","application/json");
  xhr.onreadystatechange=function(){
   if(xhr.readyState!==4||done)return;
   done=true;
   var obj={};
   try{obj=JSON.parse(xhr.responseText);}catch(_){}
   if(xhr.status>=200&&xhr.status<300)ok(obj);else fail(obj.error||("HTTP "+xhr.status),xhr.status);
  };
  xhr.ontimeout=function(){if(!done){done=true;fail("Hálózati időtúllépés",0);}};
  xhr.onerror=function(){if(!done){done=true;fail("A Házikó HTTPS kapcsolata megszakadt",0);}};
  xhr.send(data===null?null:JSON.stringify(data));
 }catch(e){if(!done)fail("Hálózati hozzáférési hiba",0);}
}
function promiseReq(method,path,data){
 return new Promise(function(resolve,reject){request(method,path,data,resolve,function(err){reject(new Error(err));});});
}
HA.callService=function(domain,service,data){
 if(domain==="lock"&&data&&data.entity_id==="lock.eloszoba_bejarati_ajto_also_zar"){
  return promiseReq("POST","/api/entry",{action:service==="unlock"?"unlock":service==="lock"?"lock":"deny",confirm:service==="unlock"?"hold":"tap"}).then(function(v){return v;});
 }
 return promiseReq("POST","/api/padcopy/service",{domain:domain,service:service,data:data||{}});
};
HA.callApi=function(method,path){
 if(method!=="GET")return Promise.reject(new Error("Csak olvasási hozzáférés"));
 return promiseReq("GET","/api/padcopy/ha?path="+encodeURIComponent(path),null);
};
HA.callWS=function(){return Promise.reject(new Error("HA WS statistics unavailable in legacy iPad bridge"));};
function routeName(){
 return /(?:\/lights|\/vilagitasok)\/?$/.test(location.pathname)?"lights":"thermostat";
}
function typeFor(name){return name==="lights"?"ziko-kiosk-lights":"ziko-kiosk-thermostat";}
function unmount(){
 if(device){
  try{device.parentNode.removeChild(device);}catch(e){}
  device=null;
 }
 root.innerHTML="";
}
function mount(name){
 if(!session)return;
 if(route===name&&device)return;
 if(!window.customElements || !customElements.get(typeFor(name))){
  message("A ZIKO Kiosk másolata inicializálódik…");return;
 }
 unmount();
 route=name;
 try{
  device=document.createElement(typeFor(name));
  device.setConfig&&device.setConfig({});
  root.appendChild(device);
  device.hass=HA;
  message("");
 }catch(e){
  message("A Kiosk megjelenítés nem indult: "+String(e.message||e).slice(0,120));
 }
}
function pairPrompt(text){
 session=false;HA.connection.connected=false;
 unmount();cover.style.display="block";
 message(text||"KIOSK-01 HTTPS párosítás szükséges");
}
function paired(){session=true;cover.style.display="none";message("");}
function refresh(){
 if(refreshing||!session)return;
 refreshing=true;
 request("GET","/api/padcopy/states",null,function(result){
  refreshing=false;
  if(!result||!result.ok||!result.states){message("Nem érkeznek Házikó adatok");HA.connection.connected=false;return;}
  HA.states=result.states;HA.connection.connected=true;
  mount(routeName());
  if(device){try{device.hass=HA;}catch(e){message("Kiosk frissítés hiba");}}
 },function(err,code){
  refreshing=false;
  HA.connection.connected=false;
  if(code===401){pairPrompt("A KIOSK-01 párosítása lejárt, add meg a kódot az iPaden.");return;}
  message("Házikó kapcsolat: "+err);
 });
}
function check(){
 request("GET","/api/status",null,function(result){
  if(!result.paired||result.pad!=="KIOSK-01"){pairPrompt("A KIOSK-01 párosítása szükséges.");return;}
  paired();refresh();
 },function(err){pairPrompt(err);});
}
function pair(){
 var input=elem("ziko-pad-code");
 var code=input.value.replace(/[^0-9]/g,"");
 input.value="";
 if(code.length!==8){message("A párosításhoz pontosan 8 számjegy szükséges");return;}
 var btn=elem("ziko-pad-pairbutton");btn.disabled=true;
 request("POST","/api/pair",{pad:"KIOSK-01",code:code},function(result){
  btn.disabled=false;paired();refresh();
 },function(err){btn.disabled=false;message("Párosítás: "+err);});
}
function onNav(){
 if(!session)return;
 mount(routeName());
 if(device){try{device.hass=HA;}catch(_){}}
}
function boot(){
 if(started)return;started=true;
 elem("ziko-pad-pairbutton").onclick=pair;
 window.addEventListener("popstate",onNav,false);
 window.addEventListener("location-changed",onNav,false);
 window.setInterval(function(){if(session)refresh();else check();},8000);
 check();
 // Web Components polyfill installation may be async on Safari 9.
 var attempts=0;
 var waiter=window.setInterval(function(){
  attempts++;
  if(session)mount(routeName());
  if(device||attempts>45)window.clearInterval(waiter);
 },600);
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot,false);else boot();
})();