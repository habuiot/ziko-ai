(()=>{
"use strict";
function kioskSpaNavigate(target){
 const url=new URL(target,window.location.href);
 if(url.origin!==window.location.origin){window.location.assign(url.href);return}
 if(window.location.pathname+window.location.search+window.location.hash===url.pathname+url.search+url.hash)return;
 try{
  window.history.pushState(null,"",url.pathname+url.search+url.hash);
  window.dispatchEvent(new CustomEvent("location-changed",{detail:{replace:false},bubbles:true}));
 }catch(_){window.location.assign(url.href)}
}

function init(){
const base=customElements.get("ziko-kiosk-thermostat");if(!base){customElements.whenDefined("ziko-kiosk-thermostat").then(init);return}if(customElements.get("ziko-kiosk-lights"))return;
const path="/ziko-kiosk-thermostat/",corridor="switch.lampa_1_kapcsolo_3";
const all=["light.awox_eglo_zm_rgb_tw","light.led_szalag_wifi_4","light.led_izzo_wifi_2","light.led_izzo_wifi","light.agy_led","light.nagyszoba_agy_led_kozep","light.led_szalag_wifi","light.furdoszoba_furdoszoba_lampa_hb_1_kapcsolo","light.led_szalag_wifi_2","light.led_szalag_wifi_3","light.nagyszoba_tv_hattervilagitas"];
const room=[
 ["nagyszoba","Nagyszoba","🛋️",["light.led_izzo_wifi","light.agy_led","light.nagyszoba_agy_led_kozep","light.led_szalag_wifi"]],
 ["agy","Ágyfények együtt","🛏️",["light.agyfenyek"]],
 ["govee","Govee · TV","📺",["light.nagyszoba_tv_hattervilagitas"]],
 ["nappali","Nappali","🪟",["light.led_izzo_wifi_2"]],
 ["konyha","Konyha","🍳",["light.awox_eglo_zm_rgb_tw","light.led_szalag_wifi_4"]],
 ["furdo","Fürdőszoba","🛁",["light.furdoszoba_furdoszoba_lampa_hb_1_kapcsolo"]],
 ["eloszoba","Előszoba","🚪",["light.led_szalag_wifi_2"]],
 ["erkely","Erkély","🌿",["light.led_szalag_wifi_3"]],
 ["kozos","Nappali + Konyha","✨",["light.konyha_nappali_osszes_feny"]],
 ["kozlekedo","Közlekedő","🚶",[corridor]],
];
const palette={warm:{name:"Melegfehér",rgb:[255,191,138]},teal:{name:"Türkiz",rgb:[0,229,212]},red:{name:"Piros",rgb:[255,0,0]}};
const svg=(name)=>{
 const paths={house:'<path d="M4 20 24 4l20 16v24H4zM17 44V28h14v16"/>',thermo:'<path d="M18 29V11a6 6 0 0 1 12 0v18a11 11 0 1 1-12 0Z"/><path d="M24 17v18"/>',bulb:'<path d="M24 4a14 14 0 0 0-8 25c2 2 3 4 3 7h10c0-3 1-5 3-7A14 14 0 0 0 24 4ZM19 40h10M20 45h8"/>',shield:'<path d="M24 3 42 10v13c0 12-8 19-18 22C14 42 6 35 6 23V10Z"/><path d="m15 24 6 6 13-14"/>',media:'<rect x="5" y="8" width="38" height="29" rx="4"/><path d="M17 44h14M24 37v7"/><path d="m20 15 13 8-13 8z"/>',power:'<path d="M24 4v20M12 12a17 17 0 1 0 24 0"/>',sun:'<circle cx="24" cy="24" r="8"/><path d="M24 3v7M24 38v7M3 24h7M38 24h7M9 9l5 5M34 34l5 5M9 39l5-5M34 14l5-5"/>',tune:'<path d="M6 11h36M6 24h36M6 37h36"/><circle cx="17" cy="11" r="4" fill="#081e2b"/><circle cx="32" cy="24" r="4" fill="#081e2b"/><circle cx="21" cy="37" r="4" fill="#081e2b"/>'};
 return `<svg class="zico-icon" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="3.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||""}</svg>`;
};
class ZikoKioskLights extends base{
 constructor(){super();
  this._levels={};this._preset={};this._kelvin=2700;this._color="#00e5d4";this._lightsBusy=false;
  const l=document.createElement("link");l.rel="stylesheet";l.href="/local/ziko-kiosk-thermostat/kiosk-lights-v1.2.15.css?v=1.2.15";this.shadowRoot.appendChild(l);
  this.shadowRoot.addEventListener("input",e=>this._inputLights(e));
 }
 connectedCallback(){
  super.connectedCallback();
  this._overlay?.shadowRoot?.addEventListener("input",e=>this._inputLights(e));
 }
 set hass(h){this._hass=h;if(!this.isConnected||this._lightsBusy||this._roomEditor)return;if(!this._lightsPending){this._lightsPending=true;requestAnimationFrame(()=>{this._lightsPending=false;this._render()})}}
 _ids(id){return id==="all"?all:(room.find(x=>x[0]===id)?.[3]||[])}
 _valid(id){return ["on","off"].includes(this._st(id)?.state)}
 _targets(id){return this._ids(id).filter(x=>this._valid(x))}
 _stats(id){
  const ids=id==="all"?[...all,corridor]:this._ids(id);
  const valid=ids.filter(x=>this._valid(x));
  return {all:ids.length,available:valid.length,on:valid.filter(x=>this._st(x)?.state==="on").length};
 }
 _level(id){
  if(Number.isFinite(this._levels[id]))return this._levels[id];
  const t=this._targets(id).find(x=>this._st(x)?.attributes?.brightness!==undefined);
  return t?Math.max(1,Math.round(Number(this._st(t).attributes.brightness||255)*100/255)):100;
 }
 _palette(id,mini){
  return `<div class="lk-pal ${mini?"small":""}" role="group" aria-label="${id} színek">${Object.entries(palette).map(([key,p])=>`<button type="button" data-act="lk-preset" data-group="${id}" data-color="${key}" class="lk-chip ${key} ${this._preset[id]===key?"chosen":""}" title="${p.name}">${mini?"":`<i></i>`}<span>${p.name}</span></button>`).join("")}</div>`;
 }
 _corridorState(){
  try{const value=JSON.parse(this._st("input_text.ziko_lights_allapot")?.state||"{}");return value&&typeof value==="object"?value:{}}
  catch(_){return {}}
 }
 _corridorTimerActive(){return this._corridorState().c==="motion"&&this._st("timer.ziko_lights_mozgas")?.state==="active"}
 _corridorSeconds(){return Math.max(10,Math.min(300,Math.round((Number(this._st("input_number.kozlekedo_lekapcsolas_kesleltetese")?.state)||100)/5)*5))}
 _corridorRemaining(){
  const timer=this._st("timer.ziko_lights_mozgas");
  if(!timer||timer.state!=="active")return null;
  const until=Date.parse(timer.attributes?.finishes_at||"");
  return Number.isFinite(until)?Math.max(0,Math.ceil((until-Date.now())/1000)):null;
 }
 _corridorTime(){const v=this._corridorRemaining();return v===null?"--:--":String(Math.floor(v/60)).padStart(2,"0")+":"+String(v%60).padStart(2,"0")}
 _corridorCard(r){
  const [id,name,emoji]=r,stats=this._stats(id),on=stats.on>0,ok=stats.available>0&&this._online();
  const pir=this._st("input_boolean.ziko_kozlekedo_pir_automatikus_feny_engedelyezve")?.state;
  const sync=this._st("input_boolean.ziko_kozlekedo_nappali_konyha_kovetes")?.state;
  const motion=this._corridorTimerActive(),secs=this._corridorSeconds();
  const toggle=(act,title,state)=>`<div class="lk-corridor-switch-row"><span>${title}</span><button type="button" role="switch" aria-checked="${state==="on"?"true":"false"}" class="lk-switch ${state==="on"?"on":""}" data-act="${act}" aria-label="${title}" ${!this._online()||!["on","off"].includes(state)?"disabled":""}><i></i></button></div>`;
  return `<article class="lk-card lk-card-corridor" data-lk-card="kozlekedo" aria-label="Közlekedő">
    <div class="lk-card-head"><span class="lk-room-emoji">${emoji}</span><div class="lk-card-identity"><strong>Közlekedő</strong><small>${ok?on?"A lámpa ég":"A lámpa lekapcsolva":"W601 nem elérhető"}</small></div></div>
    <button type="button" data-act="lk-power" data-group="kozlekedo" class="lk-corridor-power ${on?"on":""}" aria-label="Közlekedő ${on?"kikapcsolás":"bekapcsolás"}" ${ok?"":"disabled"}>${svg("power")}<strong>${on?"KIKAPCSOLÁS":"BEKAPCSOLÁS"}</strong></button>
    ${toggle("lk-corridor-sync","Nappali + Konyha követés",sync)}
    ${toggle("lk-corridor-motion","Mozgásérzékelő automatika",pir)}
    <div class="lk-corridor-time-head"><span>Lekapcsolási idő</span><strong data-lk-corridor-seconds>${secs} mp</strong></div>
    <input type="range" data-lk-corridor-range min="10" max="300" step="5" value="${secs}" class="lk-range lk-corridor-slider" style="--fill:${((secs-10)/290*100).toFixed(1)}%" aria-label="Közlekedő időzítője, másodperc" ${this._online()?"":"disabled"}>
    ${motion?`<div class="lk-corridor-count"><span>MOZGÁS · visszaszámlálás</span><strong data-lk-countdown>${this._corridorTime()}</strong></div><button type="button" class="lk-corridor-stop" data-act="lk-corridor-stop">${svg("power")} Időzítő megállítása</button>`:`<div class="lk-corridor-no-timer">${this._corridorState().c==="hold"?"Kézi tartás · nincs időzítő":"Mozgásra induló időzítő készenlétben"}</div>`}
   </article>`;
 }
 _roomCard(r){
  const [id,name,emoji]=r;
  if(id==="kozlekedo")return this._corridorCard(r);
  const stats=this._stats(id),level=this._level(id),available=stats.available>0&&this._online(),disabled=!available||this._lightsBusy?"disabled":"",on=stats.on>0;
  return `<article class="lk-card ${available?"":"offline"} ${["agy","govee","kozos"].includes(id)?"special":""}" data-lk-card="${id}" aria-label="${name}">
   <div class="lk-card-head"><span class="lk-room-emoji">${emoji}</span><div class="lk-card-identity"><strong>${name}</strong><small>${!available?"Nem elérhető":stats.on?stats.on+" aktív · "+stats.available+" elérhető":stats.available+" elérhető · KI"}</small></div><button class="lk-power ${on?"on":""}" data-act="lk-power" data-group="${id}" title="${on?"Kikapcsolás":"Bekapcsolás"}" aria-label="${name} ${on?"kikapcsolás":"bekapcsolás"}" ${disabled}>${svg("power")}</button></div>
   <div class="lk-dim-head"><span>Fényerő</span><strong data-lk-label="${id}">${level}%</strong></div>
   <input type="range" data-lk-range="${id}" min="1" max="100" value="${level}" style="--fill:${level}%" class="lk-range" ${disabled} aria-label="${name} fényerő">
   ${this._palette(id,true)}
   <div class="lk-room-custom"><button type="button" data-act="lk-editor-open" data-group="${id}" data-mode="white" ${disabled}>Fehér</button><button type="button" data-act="lk-editor-open" data-group="${id}" data-mode="color" ${disabled}>Egyedi szín</button></div>
   ${id==="govee"?`<button type="button" class="lk-dream" data-act="lk-dream" ${this._valid("switch.nagyszoba_tv_hattervilagitas_dreamview")?"":"disabled"}>DreamView ${this._st("switch.nagyszoba_tv_hattervilagitas_dreamview")?.state==="on"?"BE":"KI"}</button>`:""}
  </article>`;
 }
 _editorModal(){
  const edit=this._roomEditor;if(!edit)return "";
  const match=room.find(x=>x[0]===edit.id),name=match?.[1]||"Lámpacsoport",dreamBlocked=edit.id==="govee"&&!this._goveeFixedColor();
  const mode=edit.mode==="white"?"white":"color";
  return `<div class="lk-modal-wrap" role="presentation">
   <button type="button" class="lk-modal-backdrop" data-act="lk-editor-close" aria-label="Színállító bezárása"></button>
   <section class="lk-modal" role="dialog" aria-modal="true" aria-label="${name} egyedi színállító">
    <div class="lk-modal-header"><div><small>HELYISÉG SZÍNBEÁLLÍTÁSA</small><h2>${name}</h2></div><button type="button" class="lk-modal-close" data-act="lk-editor-close" aria-label="Bezárás">×</button></div>
    <div class="lk-modal-tabs"><button type="button" data-act="lk-editor-tab" data-mode="white" class="${mode==="white"?"active":""}">Egyedi fehér</button><button type="button" data-act="lk-editor-tab" data-mode="color" class="${mode==="color"?"active":""}">Egyedi RGB-szín</button></div>
    ${dreamBlocked?`<div class="lk-modal-warning">Govee DreamView/effekt aktív: a színvezérlés ilyenkor nem módosítja a Govee-t. Fix szín módban alkalmazható.</div>`:""}
    ${mode==="white"?`<div class="lk-modal-main"><div class="lk-modal-temp"><span>Fehérszínhőmérséklet</span><strong data-lk-editor-kelvin>${edit.kelvin} K</strong></div><input type="range" data-lk-editor-kelvin-input min="2200" max="6500" step="100" value="${edit.kelvin}" class="lk-range lk-modal-temp-range" aria-label="${name} fehérszínhőmérséklet"><div class="lk-modal-white-presets">${[[2700,"Meleg"],[4000,"Természetes"],[6500,"Hideg"]].map(([val,label])=>`<button type="button" data-act="lk-editor-kelvin-preset" data-kelvin="${val}" class="${edit.kelvin===val?"active":""}">${label}<small>${val} K</small></button>`).join("")}</div><button type="button" class="lk-modal-apply" data-act="lk-editor-apply-white" ${dreamBlocked?"disabled":""}>Fehér alkalmazása</button></div>`:
    `<div class="lk-modal-main"><div class="lk-modal-colorarea"><input type="color" data-lk-editor-color value="${edit.color}" aria-label="${name} egyedi RGB-színe"><div><strong>Egyedi RGB-szín</strong><small data-lk-editor-colorlabel>${edit.color.toUpperCase()}</small></div></div><button type="button" class="lk-modal-apply" data-act="lk-editor-apply-color" ${dreamBlocked?"disabled":""}>Szín alkalmazása</button></div>`}
    <p class="lk-modal-hint">Csak a kiválasztott helyiség/csoport lámpáit vezérli. A közlekedő kapcsolóját nem módosítja.</p>
   </section>
  </div>`;
 }
 _nav(){
  const items=[["thermostat","Thermostat","thermo",true],["lights","Világítások","bulb",true],["security","Biztonság","shield",false],["media","Média","media",false]];
  return `<nav class="kiosk-nav" aria-label="Ziko Kiosk oldalak">${items.map(([id,label,ic,ready])=>`<button type="button" class="kiosk-nav-button ${id==="lights"?"is-active":ready?"is-ready":"is-future"}" data-act="kiosk-section" data-section="${id}" title="${label}${ready?"":" – később"}" aria-label="${label}${id==="lights"?" – aktív":ready?" – megnyitás":" – előkészítve"}" ${id==="lights"?'aria-current="page"':""}>${svg(ic)}</button>`).join("")}</nav>`;
 }
 _render(){
  if(!this._container||!this._hass||this._lightsBusy)return;
  const st=this._stats("all"),powerOn=st.on>0,level=this._level("all"),disabled=!st.available||!this._online()?"disabled":"";
  const h=`<div class="kiosk lk-app">
   <header class="topbar"><div class="brand"><button class="home" data-act="go-home" aria-label="Házikó főoldal">${svg("house")}</button><h1>Ziko Kiosk</h1></div><div class="clock" id="main-clock">${new Date().toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}</div><div class="ha-wrap">${this._nav()}<button data-act="fullscreen" class="ha-ziko ${this._online()?"online":"offline"}">${svg("house")}<span>HA-Ziko</span></button></div></header>
   <main class="lk-page"><div class="lk-title"><div class="lk-titlename"><span class="lk-title-icon">${svg("bulb")}</span><div><h2>Világítások</h2><small>Összes lámpa · helyiségek · fénycsoportok</small></div></div><div class="lk-live"><i></i><strong>${st.on} világítás aktív</strong><small>${st.available}/${st.all} elérhető</small></div></div>
    <section class="lk-master" aria-label="Összes lámpa vezérlés"><div class="lk-master-header"><div class="lk-master-title"><span class="lk-main-power-icon">${svg("power")}</span><div><h3>Összes lámpa</h3><small>BE/KI · Fényerő és színek</small></div></div><button class="lk-all-btn ${powerOn?"on":""}" data-act="lk-power" data-group="all" ${disabled}>${svg("power")} ${powerOn?"MINDEN KI":"MINDEN BE"}</button></div>
     <div class="lk-master-body"><div class="lk-master-main"><div class="lk-master-label"><strong>Fényerő</strong><span data-lk-label="all">${level}%</span></div><input type="range" data-lk-range="all" class="lk-range lk-global-range" min="1" max="100" value="${level}" style="--fill:${level}%" ${disabled} aria-label="Összes világítás fényereje">${this._palette("all",false)}<span class="lk-muted">A fényerő nem változtatja a közlekedő kapcsolóját.</span></div>
     <div class="lk-custom"><div class="lk-custom-head"><strong>Egyedi fehér</strong><span data-lk-kvalue>${this._kelvin} K</span></div><input type="range" data-lk-kelvin min="2200" max="6500" step="100" value="${this._kelvin}" class="lk-range lk-k-range" aria-label="Fehér színhőmérséklet"><button class="lk-apply" data-act="lk-white" ${disabled}>${svg("thermo")} Fehér alkalmazása</button><div class="lk-custom-bottom"><div><strong>Egyedi szín</strong><small>RGB-színes lámpákhoz</small></div><input type="color" value="${this._color}" data-lk-custom aria-label="Egyedi szín"><button class="lk-apply-color" data-act="lk-color" ${disabled}>${svg("media")} Alkalmaz</button></div></div></div>
     <div class="lk-rule"><span></span> Melegfehér: közlekedő BE · Türkiz és piros: közlekedő KI · Govee DreamView alatt csak BE/KI és fényerő · fix színben színvezérlés</div>
    </section>
    <div class="lk-list-title"><strong>Helyiségek és fénycsoportok</strong><small>Önálló kapcsolás · fényerő · három alapszín</small></div>
    <section class="lk-grid" aria-label="Helyiségek és csoportok">${room.map(r=>this._roomCard(r)).join("")}</section>
   </main>
   ${this._notice?`<div class="notice ${this._warning?"warn":""}" role="status">${this._notice}</div>`:""}
   ${this._roomEditor?this._editorModal():""}
  </div>`;
  this._container.innerHTML=h;
 }
 _tick(){
  if(!this.isConnected)return;
  const c=this._container.querySelector("#main-clock");if(c)c.textContent=new Date().toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit",second:"2-digit"});
  const counter=this._container.querySelector("[data-lk-countdown]");if(counter)counter.textContent=this._corridorTime();
 }
 _inputLights(e){
  const t=e.target;if(t.matches?.("[data-lk-range]")){const id=t.dataset.lkRange,v=Math.round(Number(t.value));this._levels[id]=v;t.style.setProperty("--fill",v+"%");const n=this._container.querySelector('[data-lk-label="'+id+'"]');if(n)n.textContent=v+"%"}
  if(t.matches?.("[data-lk-kelvin]")){this._kelvin=Math.round(Number(t.value));const n=this._container.querySelector("[data-lk-kvalue]");if(n)n.textContent=this._kelvin+" K"}
  if(t.matches?.("[data-lk-corridor-range]")){const v=Math.round(Number(t.value));t.style.setProperty("--fill",((v-10)/290*100).toFixed(1)+"%");const n=this._container.querySelector("[data-lk-corridor-seconds]");if(n)n.textContent=v+" mp"}
  if(t.matches?.("[data-lk-editor-kelvin-input]")&&this._roomEditor){this._roomEditor.kelvin=Math.round(Number(t.value));const n=this._container.querySelector("[data-lk-editor-kelvin]");if(n)n.textContent=this._roomEditor.kelvin+" K"}
  if(t.matches?.("[data-lk-editor-color]")&&this._roomEditor){this._roomEditor.color=t.value;const n=this._container.querySelector("[data-lk-editor-colorlabel]");if(n)n.textContent=t.value.toUpperCase()}
 }
 _change(e){
  const t=e.target;
  if(t.matches?.("[data-lk-range]")){this._levels[t.dataset.lkRange]=Math.round(Number(t.value));this._brightness(t.dataset.lkRange)}
  if(t.matches?.("[data-lk-kelvin]"))this._kelvin=Math.round(Number(t.value));
  if(t.matches?.("[data-lk-custom]"))this._color=t.value;
  if(t.matches?.("[data-lk-editor-color]")&&this._roomEditor)this._roomEditor.color=t.value;
  if(t.matches?.("[data-lk-editor-kelvin-input]")&&this._roomEditor)this._roomEditor.kelvin=Math.round(Number(t.value));
  if(t.matches?.("[data-lk-corridor-range]"))this._corridorSetDelay(Math.round(Number(t.value)));
 }
 async _call(fn,success="Parancs elküldve"){
  if(this._lightsBusy||!this._online()){this._feedback("Nincs elérhető Házikó-kapcsolat.",true);return}
  this._lightsBusy=true;
  try{await fn();this._feedback(success)}
  catch(e){this._feedback("Világításvezérlési hiba: "+String(e?.message||e).slice(0,140),true)}
  finally{this._lightsBusy=false;this._render()}
 }
 async _power(id){
  const st=this._stats(id),ids=this._targets(id);if(!st.available){this._feedback("Nincs elérhető lámpa.",true);return}
  const op=st.on?"turn_off":"turn_on";
  return this._call(async()=>{
   const commands=[];
   if(id==="all"&&this._valid(corridor))commands.push(this._hass.callService("switch",op,{entity_id:corridor}));
   const lights=ids.filter(x=>x.startsWith("light."));
   if(lights.length)commands.push(this._hass.callService("light",op,{entity_id:lights}));
   if(id==="kozlekedo")commands.push(this._hass.callService("switch",op,{entity_id:corridor}));
   const done=await Promise.allSettled(commands);if(done.some(x=>x.status==="rejected"))throw Error("Egy vagy több lámpacsoport hibázott");
  },op==="turn_on"?"Bekapcsolási parancs elküldve.":"Kikapcsolási parancs elküldve.");
 }
 async _brightness(id){
  const ids=this._targets(id).filter(x=>x.startsWith("light.")&&!(this._st(x)?.attributes?.supported_color_modes||[]).includes("onoff"));
  if(!ids.length){this._feedback("Nincs elérhető szabályozható lámpa.",true);return}
  return this._call(()=>this._hass.callService("light","turn_on",{entity_id:ids,brightness_pct:this._level(id),transition:0}),"Fényerőparancs elküldve.");
 }
 _goveeFixedColor(){
  const light=this._st("light.nagyszoba_tv_hattervilagitas");
  return this._valid("light.nagyszoba_tv_hattervilagitas")&&this._st("switch.nagyszoba_tv_hattervilagitas_dreamview")?.state==="off"&&!light?.attributes?.effect;
 }
 async _presetAction(id,color){
  const cfg=palette[color];if(!cfg)return;
  const ids=this._targets(id);if(!ids.length&&id!=="all"){this._feedback("A fénycsoport nem elérhető.",true);return}
  if(id==="kozlekedo"){this._feedback("A közlekedő csak BE/KI.",true);return}
  return this._call(async()=>{
   if(id==="all"){
    if(this._valid(corridor))await this._hass.callService("switch",color==="warm"?"turn_on":"turn_off",{entity_id:corridor});
    await this._hass.callService("script","haziko3_fenyjelenet",{profile:color});
    if(this._goveeFixedColor()){
     const data=color==="warm"?{entity_id:"light.nagyszoba_tv_hattervilagitas",color_temp_kelvin:2700,brightness_pct:100}:{entity_id:"light.nagyszoba_tv_hattervilagitas",rgb_color:cfg.rgb,brightness_pct:100};
     await this._hass.callService("light","turn_on",data);
    }
   }else if(id==="govee"){
    if(!this._goveeFixedColor())throw Error("A Govee DreamView vagy effekt módban van; fix szín mód szükséges.");
    const data=color==="warm"?{entity_id:ids,color_temp_kelvin:2700,brightness_pct:this._level(id)}:{entity_id:ids,rgb_color:cfg.rgb,brightness_pct:this._level(id)};
    await this._hass.callService("light","turn_on",data);
   }else{
    await this._hass.callService("script","ziko_color_dispatch",{targets:ids,command:"turn_on",parameters:color==="warm"?{color_temp_kelvin:2700,brightness_pct:this._level(id)}:{rgb_color:cfg.rgb,brightness_pct:this._level(id)}});
   }
   this._preset[id]=color;
  },cfg.name+" fényparancs elküldve.");
 }
 _whiteRgb(kelvin){
  const t=kelvin/100,round=x=>Math.max(0,Math.min(255,Math.round(x)));
  return [round(t<=66?255:329.698727446*Math.pow(t-60,-0.1332047592)),round(t<=66?99.4708025861*Math.log(t)-161.1195681661:288.1221695283*Math.pow(t-60,-0.0755148492)),round(t>=66?255:t<=19?0:138.5177312231*Math.log(t-10)-305.0447927307)];
 }
 async _white(id="all",requestedKelvin=null){
  const initial=this._targets(id);
  const targets=initial.filter(x=>x!=="light.nagyszoba_tv_hattervilagitas"||this._goveeFixedColor());
  const kelvin=Math.max(2200,Math.min(6500,Math.round(Number(requestedKelvin??this._kelvin)||2700))),level=this._level(id);
  const ct=targets.filter(x=>(this._st(x)?.attributes?.supported_color_modes||[]).includes("color_temp"));
  const rgb=targets.filter(x=>!ct.includes(x)&&(this._st(x)?.attributes?.supported_color_modes||[]).some(m=>["hs","xy","rgb","rgbw","rgbww"].includes(m)));
  const simple=targets.filter(x=>!ct.includes(x)&&!rgb.includes(x));
  if(!targets.length){this._feedback(id==="govee"?"DreamView/effekt módban nincs kézi színparancs.":"Nincs elérhető fehérszabályozású lámpa.",true);return}
  return this._call(async()=>{
   if(id==="all"&&this._valid(corridor))await this._hass.callService("switch","turn_on",{entity_id:corridor});
   const calls=ct.map(x=>{
    const a=this._st(x)?.attributes||{},val=Math.min(a.max_color_temp_kelvin||6500,Math.max(a.min_color_temp_kelvin||2000,kelvin));
    return this._hass.callService("light","turn_on",{entity_id:x,color_temp_kelvin:val,brightness_pct:level});
   });
   if(rgb.length)calls.push(this._hass.callService("script","ziko_color_dispatch",{targets:rgb,command:"turn_on",parameters:{rgb_color:this._whiteRgb(kelvin),brightness_pct:level}}));
   if(simple.length)calls.push(this._hass.callService("light","turn_on",{entity_id:simple}));
   const result=await Promise.allSettled(calls);
   if(result.some(x=>x.status==="rejected"))throw Error("Egy vagy több lámpa nem fogadta a fehérparancsot");
  },"Egyedi fehér alkalmazva.");
 }
 async _colorAction(id="all",hexValue=null){
  const hex=hexValue??this._color;
  if(!/^#[0-9a-f]{6}$/i.test(hex||"")){this._feedback("Érvénytelen RGB-kód.",true);return}
  const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
  const targets=this._targets(id).filter(x=>(this._st(x)?.attributes?.supported_color_modes||[]).some(m=>["hs","xy","rgb","rgbw","rgbww"].includes(m)));
  const G="light.nagyszoba_tv_hattervilagitas",allowed=targets.filter(x=>x!==G||this._goveeFixedColor());
  if(!allowed.length){this._feedback(id==="govee"?"DreamView/effekt módban nincs kézi színparancs.":"Nincs elérhető színes lámpa.",true);return}
  return this._call(async()=>{
   if(id==="all"&&this._valid(corridor))await this._hass.callService("switch","turn_off",{entity_id:corridor});
   const other=allowed.filter(x=>x!==G),level=this._level(id);
   if(other.length)await this._hass.callService("script","ziko_color_dispatch",{targets:other,command:"turn_on",parameters:{rgb_color:rgb,brightness_pct:level}});
   if(allowed.includes(G))await this._hass.callService("light","turn_on",{entity_id:G,rgb_color:rgb,brightness_pct:level});
  },"Egyedi színparancs elküldve.");
 }
 async _corridorToggle(entity){
  const current=this._st(entity)?.state;
  if(!["on","off"].includes(current)){this._feedback("Az automatika kapcsolója nem elérhető.",true);return}
  return this._call(()=>this._hass.callService("input_boolean",current==="on"?"turn_off":"turn_on",{entity_id:entity}),"Automatika beállítása elküldve.");
 }
 async _corridorSetDelay(value){
  const entity="input_number.kozlekedo_lekapcsolas_kesleltetese",seconds=Math.max(10,Math.min(300,Math.round(Number(value)/5)*5));
  if(!Number.isFinite(seconds)||!this._valid(corridor)){this._feedback("A közlekedő időzítése nem elérhető.",true);return}
  return this._call(async()=>{
   await this._hass.callService("input_number","set_value",{entity_id:entity,value:seconds});
   if(this._corridorTimerActive())await this._hass.callService("timer","start",{entity_id:"timer.ziko_lights_mozgas",duration:seconds});
  },"Közlekedő késleltetés: "+seconds+" mp. Aktív mozgásidőzítőnél újraszámolva.");
 }
 async _corridorStopTimer(){
  if(!this._corridorTimerActive()){this._feedback("Nincs aktív mozgásidőzítő.",true);return}
  return this._call(()=>this._hass.callService("script","ziko_lights_core",{request:{op:"double",at:Date.now()/1000}}),"Mozgásidőzítő leállítva, a világítás kézi tartásra vált.");
 }
 _openEditor(id,mode){
  if(id==="kozlekedo"||!room.some(x=>x[0]===id)){this._feedback("A közlekedő csak BE/KI kapcsoló.",true);return}
  if(!this._targets(id).length){this._feedback("A fénycsoport nem elérhető.",true);return}
  const saved=this._roomCustomSaved?.[id]||{};
  this._roomEditor={id,mode:mode==="color"?"color":"white",kelvin:saved.kelvin||2700,color:saved.color||"#00e5d4"};
  this._render();
 }
 _closeEditor(){this._roomEditor=null;this._render()}
 async _applyEditor(mode){
  const e=this._roomEditor;if(!e)return;
  const id=e.id,kelvin=e.kelvin,color=e.color;
  if(!this._roomCustomSaved)this._roomCustomSaved={};
  this._roomCustomSaved[id]={kelvin,color};
  this._roomEditor=null;
  return mode==="white"?this._white(id,kelvin):this._colorAction(id,color);
 }
 async _click(e){
  const b=e.target.closest?.("button[data-act]");if(!b||b.disabled)return;
  const act=b.dataset.act,id=b.dataset.group;
  if(act==="kiosk-section"){
   const section=b.dataset.section;
   if(section==="thermostat"){kioskSpaNavigate(path+"attekintes");return}
   if(section==="lights"){this._feedback("A Világítások oldal aktív.");return}
   if(section==="security"||section==="media"){this._feedback((section==="security"?"Biztonság":"Média")+" – az oldal később készül el.");return}
  }
  if(act==="lk-editor-open")return this._openEditor(id,b.dataset.mode);
  if(act==="lk-editor-close")return this._closeEditor();
  if(act==="lk-editor-tab"&&this._roomEditor){this._roomEditor.mode=b.dataset.mode;this._render();return}
  if(act==="lk-editor-kelvin-preset"&&this._roomEditor){this._roomEditor.kelvin=Number(b.dataset.kelvin);this._render();return}
  if(act==="lk-editor-apply-white")return this._applyEditor("white");
  if(act==="lk-editor-apply-color")return this._applyEditor("color");
  if(act==="lk-corridor-sync")return this._corridorToggle("input_boolean.ziko_kozlekedo_nappali_konyha_kovetes");
  if(act==="lk-corridor-motion")return this._corridorToggle("input_boolean.ziko_kozlekedo_pir_automatikus_feny_engedelyezve");
  if(act==="lk-corridor-stop")return this._corridorStopTimer();
  if(act==="lk-power")return this._power(id);
  if(act==="lk-preset")return this._presetAction(id,b.dataset.color);
  if(act==="lk-white")return this._white();
  if(act==="lk-color")return this._colorAction();
  if(act==="lk-dream"){
   const ent="switch.nagyszoba_tv_hattervilagitas_dreamview",state=this._st(ent)?.state;
   if(!["on","off"].includes(state)){this._feedback("Govee DreamView nem elérhető.",true);return}
   return this._call(()=>this._hass.callService("switch",state==="on"?"turn_off":"turn_on",{entity_id:ent}),"DreamView parancs elküldve.");
  }
  return super._click(e);
 }
}
customElements.define("ziko-kiosk-lights",ZikoKioskLights);
}
init();
})();