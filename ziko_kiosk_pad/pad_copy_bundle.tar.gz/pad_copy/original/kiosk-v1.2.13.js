
/* Ziko Kiosk v1.2.13 · Home Assistant native custom card
 * No synthetic sensor data; all controls use authenticated hass.callService.
 * Isolated from the Házikó 3.0 climate producer.
 */
(() => {
"use strict";
function kioskSpaNavigate(target){
 const url=new URL(target,window.location.href);
 if(url.origin!==window.location.origin){window.location.assign(url.href);return}
 if(window.location.pathname+window.location.search+window.location.hash===url.pathname+url.search+url.hash)return;
 try{
  window.history.pushState(null,"",url.pathname+url.search+url.hash);
  window.dispatchEvent(new CustomEvent("location-changed",{detail:{replace:false},bubbles:true}));
 }catch(_){window.location.assign(url.href)}
}

const E={
 rooms:[
  {name:"Nagyszoba", climate:"climate.sonoff_trvzb",rad:"sensor.sonoff_trvzb_local_temperature",temp:"sensor.erkely_erkely_homero_homerseklet",hum:"sensor.erkely_erkely_homero_paratartalom"},
  {name:"Nappali", climate:"climate.sonoff_trvzb_2",rad:"sensor.sonoff_trvzb_local_temperature_2",temp:"sensor.konyha_konyha_homero_homerseklet",hum:"sensor.konyha_konyha_homero_paratartalom"}
 ],
 dryer:{
  power:"sensor.nagyszoba_fokapcsolo_teljesitmeny",
  energy:"sensor.nagyszoba_fokapcsolo_teljes_energiamennyiseg",
  start:"input_number.torolkozoszarito_ciklus_kezdo_energia",
  timer:"timer.torolkozoszarito_idozito",
  relay:"switch.nagyszoba_fokapcsolo_1_aljzat",
  price:"input_number.ziko_energy_fix_tarifa_ft_kwh",
  billing:"input_number.ziko_energy_szamlazasi_fordulonap"
 },
 schedule:{enabled:"input_boolean.ziko_kiosk_torolkozoszarito_napi_utemezes",time:"input_datetime.ziko_kiosk_torolkozoszarito_inditasi_ido",minutes:"input_number.ziko_kiosk_torolkozoszarito_utemezes_percek"} ,
 air:{
  power:"switch.zhimi_de_874594721_rmb1_on_p_2_1",
  mode:"select.zhimi_de_874594721_rmb1_mode_p_2_4",
  manual:"number.zhimi_de_874594721_rmb1_favorite_level_p_9_11",
  rpm:"sensor.zhimi_de_874594721_rmb1_moto_speed_rpm_p_9_1",
  pm:"sensor.zhimi_de_874594721_rmb1_pm2_5_density_p_3_4",
  temp:"sensor.zhimi_de_874594721_rmb1_temperature_p_3_7",
  hum:"sensor.zhimi_de_874594721_rmb1_relative_humidity_p_3_1",
  filter:"sensor.zhimi_de_874594721_rmb1_filter_life_level_p_4_1"
 }
};
const NF=new Intl.NumberFormat("hu-HU",{maximumFractionDigits:0});
const NF1=new Intl.NumberFormat("hu-HU",{minimumFractionDigits:1,maximumFractionDigits:1});
const FF=new Intl.NumberFormat("hu-HU",{maximumFractionDigits:2});
const NF3=new Intl.NumberFormat("hu-HU",{minimumFractionDigits:3,maximumFractionDigits:3});
const timeFmt=new Intl.DateTimeFormat("hu-HU",{timeZone:"Europe/Budapest",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false});
function finite(v){if(v===null||v===undefined||v===""||v==="unknown"||v==="unavailable")return null;const n=Number(v);return Number.isFinite(n)?n:null}
function fmt(v,d){const n=finite(v);if(n===null)return "—";return (d===3?NF3:d===2?FF:d===1?NF1:NF).format(n)}
function temp(v){return fmt(v,1)+" °C"}
function cents(v){return fmt(v,2)+" Ft"}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function polar(cx,cy,r,deg){const a=deg*Math.PI/180;return [cx+Math.sin(a)*r,cy-Math.cos(a)*r]}
function arc(cx,cy,r,begin,end){const s=polar(cx,cy,r,begin),e=polar(cx,cy,r,end);return "M "+s[0].toFixed(1)+" "+s[1].toFixed(1)+" A "+r+" "+r+" 0 "+(end-begin>180?1:0)+" 1 "+e[0].toFixed(1)+" "+e[1].toFixed(1)}
function elapsedSecs(v){if(!v)return null;if(typeof v==="number")return v;const p=String(v).split(":").map(Number);if(p.some(x=>!Number.isFinite(x)))return null;return p.reduce((t,n)=>t*60+n,0)}
function hhmmss(seconds){const n=Math.max(0,Math.round(seconds||0));return [Math.floor(n/3600),Math.floor(n%3600/60),n%60].map(x=>String(x).padStart(2,"0")).join(":")}
function humanTime(t){try{return new Date(t).toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit"})}catch{return "—"}}
const SOURCE_LABELS=["Kért","Radiátor","Benti","Pára"];
const SOURCE_COLORS=["#ff9b18","#ff2d64","#00e4f0","#9653da"];
function zicoIcon(name,css=""){
 const paths={
  house:'<path d="M4 22 24 5l20 17M10 20v23h28V20M19 43V28h10v15"/>',
  radiator:'<path d="M8 15v28M17 15v28M26 15v28M35 15v28M3 18h39M3 38h39M11 3v8M20 3v8M29 3v8M38 3v8M42 27h5M42 35h5"/>',
  towel:'<path d="M8 4v40M40 4v40M8 8h32M8 16h32M8 24h32M8 32h32M8 40h32"/>',
  bulb:'<path d="M24 4a14 14 0 0 0-8 25c2 2 3 4 3 7h10c0-3 1-5 3-7A14 14 0 0 0 24 4ZM19 40h10M20 45h8M8 13l-4-3M40 13l4-3M5 25h-4M43 25h4"/>' ,
  shield:'<path d="M24 3 42 10v13c0 12-8 19-18 22C14 42 6 35 6 23V10Z"/><path d="m15 24 6 6 13-14"/>',
  media:'<rect x="5" y="8" width="38" height="29" rx="4"/><path d="M17 44h14M24 37v7"/><path d="m20 15 13 8-13 8z" fill="none" stroke-linejoin="round"/>',
  thermo:'<path d="M18 29V9a6 6 0 0 1 12 0v20a11 11 0 1 1-12 0ZM24 14v22M35 9v13M40 13v9"/>',
  drop:'<path d="M24 3C18 12 8 24 8 32a16 16 0 0 0 32 0C40 24 30 12 24 3Z"/>',
  power:'<path d="M24 4v21M13 11a18 18 0 1 0 22 0"/>',
  flame:'<path d="M27 3c1 11-7 14-4 24-7-3-8-8-8-11C5 27 9 44 24 44c13 0 20-12 14-24-3 7-6 9-10 11 4-11-1-18-1-28Z"/>',
  auto:'<circle cx="23" cy="23" r="17"/><path d="m31 22-8-12-8 24M18 26h10M33 35l8 3-3-8"/>',
  calendar:'<rect x="5" y="9" width="38" height="34" rx="4"/><path d="M13 4v11M35 4v11M5 20h38M13 27h5M23 27h5M33 27h4M13 35h5M23 35h5"/>',
  timer:'<circle cx="24" cy="26" r="17"/><path d="M24 15v12l8 5M18 4h12"/>',
  lightning:'<path d="M28 3 9 27h15l-4 18 19-26H24Z"/>',
  cycle:'<path d="M7 21a17 17 0 0 1 30-8l5 5M42 9v9h-9M41 27a17 17 0 0 1-30 8l-5-5M6 39v-9h9"/>',
  wind:'<path d="M4 16h25c13 0 13-16 3-16-6 0-9 4-9 8M4 25h33c13 0 11 15 3 15-6 0-9-4-9-8M4 34h17c10 0 12 12 3 12-5 0-8-3-8-6"/>',
  fan:'<circle cx="24" cy="24" r="5"/><path d="M24 18c-15-3-15-18-4-16 9 2 7 10 4 16ZM29 24c3-15 18-15 16-4-2 9-10 7-16 4ZM23 29c-15 3-15 18-4 16 9-2 7-10 4-16ZM18 23C15 8 0 8 2 19c2 9 10 7 16 4Z"/>',
  leaf:'<path d="M43 4C19 5 3 15 7 32c3 13 18 12 26 2C42 24 43 4 43 4ZM4 45C13 32 24 26 35 18"/>',
  pm:'<circle cx="12" cy="12" r="3"/><circle cx="27" cy="8" r="2"/><circle cx="39" cy="15" r="3"/><circle cx="8" cy="28" r="3"/><circle cx="25" cy="24" r="2"/><circle cx="38" cy="33" r="3"/><circle cx="15" cy="40" r="2"/>',
  play:'<path d="M13 5 42 24 13 43Z" stroke-linejoin="round" fill="currentColor" stroke-width="1"/>',
  pause:'<rect x="10" y="7" width="10" height="34" rx="2" fill="currentColor" stroke="none"/><rect x="28" y="7" width="10" height="34" rx="2" fill="currentColor" stroke="none"/>',
  stop:'<rect x="10" y="10" width="28" height="28" rx="4" fill="currentColor" stroke="none"/>',
  chevron:'<path d="m17 9 14 15-14 15"/>',
  dots:'<circle cx="24" cy="10" r="3" fill="currentColor" stroke="none"/><circle cx="24" cy="24" r="3" fill="currentColor" stroke="none"/><circle cx="24" cy="38" r="3" fill="currentColor" stroke="none"/>'
 };
 return `<svg class="zico-icon ${css}" viewBox="0 0 48 48" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none" aria-hidden="true">${paths[name]||""}</svg>`;
}
class ZikoKioskThermostat extends HTMLElement {
 constructor(){
  super();this.attachShadow({mode:"open"});
  this._container=document.createElement("div");this._container.className="stage";
  const link=document.createElement("link");link.rel="stylesheet";link.href="/local/ziko-kiosk-thermostat/kiosk-v1.2.9.css?v=1.2.9";
  this.shadowRoot.append(link,this._container);
  this._minutes=30;this._notice="";this._warning=false;
   this._airStorageKey="ziko-kiosk:air-purifier-manual-preset:v1";this._airManualLevel=null;this._airManualPending=null;
   this._airPollAt=0;this._airPolling=false;this._airTelemetry={rpm:null,manual:null};
   try{const saved=localStorage.getItem(this._airStorageKey);if(saved!==null&&/^(?:[0-9]|1[0-4])$/.test(saved))this._airManualLevel=Number(saved)}catch(_){}

  this._history={};this._historyAt=0;this._busy=false;this._billingUsage=null;this._billingPartial=false;this._billingAt=0;
  this.shadowRoot.addEventListener("click",e=>this._click(e));
  this.shadowRoot.addEventListener("change",e=>this._change(e));
  this._bindEntryEvents(this.shadowRoot);
 }
 setConfig(config){this._config=config||{}}
 getCardSize(){return 12}
 connectedCallback(){
  // The self-contained kiosk surface covers only this dashboard and leaves
  // other HA screens intact; removing the card restores the original UI.
  if(!this._overlay){
   const overlay=document.createElement("div");
   overlay.id="ziko-kiosk-thermostat-viewport";
   overlay.style.cssText="position:fixed;inset:0;z-index:2147483647;background:#020913;overflow:auto;margin:0;padding:0";
   const surface=overlay.attachShadow({mode:"open"});
   for(const item of this.shadowRoot.querySelectorAll("link"))surface.appendChild(item.cloneNode(true));
   surface.appendChild(this._container);
   surface.addEventListener("click",e=>this._click(e));
   surface.addEventListener("change",e=>this._change(e));
   this._bindEntryEvents(surface);
   if(!this._noSelectStyle){
    const style=document.createElement("style");
    style.textContent="html,body,body *,#ziko-kiosk-thermostat-viewport,#ziko-kiosk-thermostat-viewport *{user-select:none!important;-webkit-user-select:none!important;-webkit-touch-callout:none!important}";
    style.id="ziko-kiosk-thermostat-no-text-selection";
    document.head.appendChild(style);this._noSelectStyle=style;
   }
   document.body.appendChild(overlay);
   this._overlay=overlay;
  }
  this._interval=setInterval(()=>this._tick(),1000);this._airPollAt=0;this._airRefresh();
  this._render();
 }
 disconnectedCallback(){
  clearTimeout(this._entryHoldTimer);this._entryHoldTimer=null;this._entryPress=null;
  this._noSelectStyle?.remove();this._noSelectStyle=null;
  if(this._interval)clearInterval(this._interval);this._interval=null;
  if(this._overlay){
   this.shadowRoot.appendChild(this._container);
   this._overlay.remove();
   this._overlay=null;
  }
 }
 set hass(v){
  this._hass=v;
  if(!this.isConnected)return;
  if(this._refreshing)return;
  const now=Date.now();
  if(!this._historyAt||now-this._historyAt>5*60*1000)this._loadHistory();
  if(!this._billingAt||now-this._billingAt>15*60*1000)this._loadBilling();
  if(!this._renderPending){
   this._renderPending=true;
   requestAnimationFrame(()=>{this._renderPending=false;this._render()})
  }
 }
 _st(id){return this._hass&&this._hass.states?this._hass.states[id]:null}
 _n(id){return finite(this._st(id)?.state)}
 _online(){return !!this._hass&&(this._hass.connection?.connected!==false)&&navigator.onLine!==false}
 _tempRoom(r){const c=this._st(r.climate);return {target:finite(c?.attributes?.temperature),current:finite(c?.attributes?.current_temperature),mode:c?.state||"unavailable",action:c?.attributes?.hvac_action||""}}
 _dial(x,i){
 const target=x.target===null?null:Number(x.target),frac=Math.max(0,Math.min(1,((target??4)-4)/31));
 const end=225+270*frac,p=polar(150,150,114,end),gradient="gauge-warm-"+i;
 return `<div class="gauge" role="group" aria-label="Hőmérséklet-szabályozás"><svg viewBox="0 0 300 300" aria-hidden="true">
 <defs><linearGradient id="${gradient}" x1="0" y1="1" x2="1" y2="0"><stop offset="0%" stop-color="#ff6208"/><stop offset="65%" stop-color="#ff8a06"/><stop offset="100%" stop-color="#ff7410"/></linearGradient><filter id="gauge-glow-${i}" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="6"/></filter></defs>
 <path d="${arc(150,150,114,225,495)}" stroke="#22313a" stroke-width="28" stroke-linecap="round" fill="none"/>
 ${x.mode==="off"?"":`<path d="${arc(150,150,114,225,end)}" stroke="url(#${gradient})" stroke-width="30" stroke-linecap="round" fill="none"/><circle cx="${p[0]}" cy="${p[1]}" r="14" stroke="#ff6423" stroke-width="8" fill="#fff" filter="url(#gauge-glow-${i})"/><circle cx="${p[0]}" cy="${p[1]}" r="13" stroke="#ff6b31" stroke-width="3" fill="#fff"/>`}
 </svg><div class="gauge-center"><div class="state ${x.action==="heating"?"heat":""}">${x.mode==="off"?"Kikapcsolva":x.action==="heating"?"Fűtés":x.mode==="auto"?"Automata":"Tétlen"}</div><div class="temp">${fmt(target,1)}<small>°C</small></div><div class="rad-now">${zicoIcon("thermo","mini-thermo")} ${temp(x.current)}</div></div>
 <button type="button" data-act="target-minus" data-room="${i}" class="gauge-target gauge-target-minus" aria-label="Célhőmérséklet mínusz fél fok" title="−0,5 °C"></button><button type="button" data-act="target-plus" data-room="${i}" class="gauge-target gauge-target-plus" aria-label="Célhőmérséklet plusz fél fok" title="+0,5 °C"></button></div>`;
}
 _plot(room){
 const item=this._history[room.name];if(!item?.series)return `<div class="chartplot no-data">${item?.error?"Nincs mérési előzmény":"Mérések betöltése…"}</div>`;
 const tempVals=item.series.slice(0,3).flatMap(list=>list.map(p=>p.v).filter(Number.isFinite));
 const humVals=(item.series[3]||[]).map(p=>p.v).filter(Number.isFinite);
 const lowT=Math.min(18,...tempVals)-.1,highT=Math.max(30,...tempVals)+.1,lowH=Math.min(30,...humVals)-.1,highH=Math.max(60,...humVals)+.1;
 const x0=38,x1=364,y0=12,y1=134;
 const xx=t=>x0+Math.max(0,Math.min(1,(t-item.start)/(item.end-item.start)))*(x1-x0);
 const yy=(v,i)=>y1-(v-(i===3?lowH:lowT))/((i===3?highH:highT)-(i===3?lowH:lowT))*(y1-y0);
 const grid=Array.from({length:4},(_,i)=>{const y=y0+i*(y1-y0)/3;return `<path d="M${x0} ${y}H${x1}" stroke="#2b4457" stroke-width="1" opacity=".85"/>`}).join("");
 const vgrid=Array.from({length:6},(_,i)=>{const x=x0+i*(x1-x0)/5;return `<path d="M${x} ${y0}V${y1}" stroke="#234051" stroke-width=".8" opacity=".4"/>`}).join("");
 const paths=item.series.map((arr,i)=>{const ps=arr.filter(p=>Number.isFinite(p.v)&&Number.isFinite(p.t)).sort((a,b)=>a.t-b.t);
 if(!ps.length)return "";const line=ps.map((p,j)=>(j?"L":"M")+xx(p.t).toFixed(1)+" "+yy(p.v,i).toFixed(1)).join(" ");
 return ps.length===1?`<circle cx="${xx(ps[0].t)}" cy="${yy(ps[0].v,i)}" r="3" fill="${SOURCE_COLORS[i]}"/>`:`<path d="${line}" fill="none" stroke="${SOURCE_COLORS[i]}" stroke-width="${i===0?3:3.5}" stroke-linecap="round" stroke-linejoin="round" ${i===0?'stroke-dasharray="9 7"':""}/>`}).join("");
 const ticks=Array.from({length:4},(_,i)=>{const y=y0+i*(y1-y0)/3,t=Math.round(highT-i*(highT-lowT)/3),h=Math.round(highH-i*(highH-lowH)/3);return `<text x="0" y="${y+4}" class="chart-axis">${t} °C</text><text x="402" y="${y+4}" class="chart-axis" text-anchor="end">${h} %</text>`}).join("");
 const times=Array.from({length:5},(_,i)=>{const time=item.start+(item.end-item.start)*i/4;return `<text x="${xx(time)}" y="157" text-anchor="middle" class="chart-axis">${esc(humanTime(time))}</text>`}).join("");
 return `<div class="chartplot"><svg viewBox="0 0 408 166" preserveAspectRatio="none" role="img" aria-label="Valós hatórás hőmérséklet- és páratartalom-grafikon">${grid}${vgrid}${paths}${ticks}${times}</svg></div>`;
}
 _chart(room,x){
 const vals=[x.target,this._n(room.rad)??x.current,this._n(room.temp),this._n(room.hum)];
 const classes=["orange","pink","cyan","purple"];
 const legends=vals.map((v,i)=>`<div class="legend"><span class="legend-dot ${classes[i]}"></span><span>${SOURCE_LABELS[i]}</span><b>${i===3?fmt(v,0)+" %":temp(v)}</b></div>`).join("");
 return `<div class="chartbox"><div class="chart-head">${legends}</div>${this._plot(room)}</div>`;
}
 _radiator(room,i){
 const x=this._tempRoom(room),indoor=this._n(room.temp),humidity=this._n(room.hum);
 const modes=[["off","power","Kikapcsolva"],["heat","flame","Fűtés"],["auto","auto","Automatikus"]];
 const modeBtns=modes.map(([mode,icon,title])=>`<button type="button" data-act="hvac" data-room="${i}" data-mode="${mode}" class="${x.mode===mode?"selected":""} ${mode==="heat"?"heating-mode":""}" aria-label="${title}" title="${title}">${zicoIcon(icon)}</button>`).join("");
 return `<section class="panel radiator" aria-label="${room.name} radiátor">
 <div class="rad-grid"><div class="rad-left"><div class="rad-head"><div class="rad-mark">${zicoIcon("radiator")}</div><div class="rad-titlebox"><h2>${room.name}</h2><span>Radiátor</span></div><button class="rad-menu" type="button" data-act="rad-menu" data-room="${i}" aria-label="${room.name} információ">${zicoIcon("dots")}</button></div>
 ${this._dial(x,i)}</div>
 <div class="rad-right">${this._chart(room,x)}<div class="indoor-pair">
 <div class="indoor-tile"><span class="tile-symbol">${zicoIcon("thermo")}</span><div><span class="k">Hőmérséklet</span><strong>${temp(indoor)}</strong></div></div>
 <div class="indoor-tile"><span class="tile-symbol">${zicoIcon("drop")}</span><div><span class="k">Páratartalom</span><strong>${fmt(humidity,0)} %</strong></div></div></div>
 <div class="hvac-row">${modeBtns}</div></div></div></section>`;
}
 _towelCycleWh(T,relay,energy,baseline){
  const stamp=this._st(T.start);
  const key=baseline===null?null:baseline.toFixed(6)+"|"+(stamp?.last_changed||stamp?.last_updated||"");
  const measured=energy===null||baseline===null||energy+0.0000001<baseline?null:Math.max(0,Math.round((energy-baseline)*1000));
  let snapshot=this._cycleWhSnapshot;
  if(!snapshot||snapshot.key!==key){
   let saved=null;
   if(key!==null){
    try{saved=JSON.parse(localStorage.getItem("ziko-thermostat-towel-last-cycle-wh-v1")||"null")}catch(_){}
   }
   if(saved?.key===key&&saved.frozen===true&&Number.isSafeInteger(saved.wh)&&saved.wh>=0){
    snapshot={key,wh:saved.wh,frozen:true};
   }else{
    snapshot={key,wh:measured,frozen:relay==="off"};
   }
   this._cycleWhSnapshot=snapshot;
  }
  if(!snapshot.frozen){
   if(measured!==null)snapshot.wh=Math.max(snapshot.wh??0,measured);
   if(relay==="off")snapshot.frozen=true;
  }
  if(snapshot.frozen&&key!==null&&snapshot.wh!==null){
   try{localStorage.setItem("ziko-thermostat-towel-last-cycle-wh-v1",JSON.stringify({key,wh:snapshot.wh,frozen:true}))}catch(_){}
  }
  return snapshot.wh;
 }
 _towel(){
 const T=E.dryer,relay=this._st(T.relay)?.state,power=this._n(T.power),energy=this._n(T.energy),base=this._n(T.start),rate=this._n(T.price),timer=this._st(T.timer);
 const cycleWh=this._towelCycleWh(T,relay,energy,base);
 const cycleCost=cycleWh===null||rate===null?null:cycleWh*rate/1000;
 const bill=this._billingUsage,billCost=bill===null||rate===null?null:bill*rate;
 const on=relay==="on",active=timer?.state==="active",paused=timer?.state==="paused",goodRelay=["on","off"].includes(relay),goodPower=power!==null&&power>=0&&power<3000;
 const canOn=this._online()&&!this._busy&&goodRelay&&goodPower;
 const canTimed=canOn&&this._st("automation.torolkozoszarito_idozitett_inditas")?.state==="on"&&this._st("automation.torolkozoszarito_idozito_lejart")?.state==="on"&&["idle","active","paused"].includes(timer?.state);
 const canOff=this._online()&&!this._busy,remaining=active?this._timerSecs():paused?(elapsedSecs(timer?.attributes?.remaining)??this._minutes*60):this._minutes*60;
 const wattsEntity=this._st(T.power),updated=Date.parse(wattsEntity?.last_updated||wattsEntity?.last_changed||"");
 const wattAge=Number.isFinite(updated)?Date.now()-updated:null;
 const measured=power!==null&&power>=0&&power<3000;
 const fresh=wattAge!==null&&wattAge>=0&&wattAge<=180000;
 const verifiedHeat=on&&measured&&power>=50&&fresh;
 const wattText=measured?fmt(power,1)+" W":"nincs mérés";
 const heatWarning=on&&!verifiedHeat;
 const heatReason=!measured?"TELJESÍTMÉNYMÉRÉS NINCS · FŰTÉS NEM IGAZOLT":!fresh?"NEM FRISS MÉRÉS · FŰTÉS NEM IGAZOLT":"0 W / ALACSONY FOGYASZTÁS · FŰTÉS NEM IGAZOLT";
 const stateText=!goodRelay?"NINCS KAPCSOLAT":on?(paused?"VESZÉLY: IDŐZÍTŐ SZÜNETEL":verifiedHeat?(active?"FŰTÉS IGAZOLVA · "+wattText:"KÉZI FŰTÉS IGAZOLVA · "+wattText):(active?"IDŐZÍTŐ FUT · ":"KÉZI BE · ")+heatReason):(active?"ELTÉRÉS: IDŐZÍTŐ FUT, KONNEKTOR KI":"KIKAPCSOLVA");
 const stateClass=!goodRelay?"offline":active&&!on?"mismatch":paused&&on?"mismatch":heatWarning?"mismatch":on?(active?"timed":"manual"):"off";
 const manualInfo=on&&!active?"KÉZI ÜZEM · NINCS AUTOMATIKUS KIKAPCSOLÁS":"";
 const energyRow=(ico,label,value,money)=>`<div class="energy-tile"><span class="energy-ico">${zicoIcon(ico)}</span><div class="energy-main"><div class="metric-label">${label}</div><div class="metric-value">${value}</div></div><div class="money">${money}</div></div>`;
 return `<section class="panel towel towel-quick" aria-label="Törölközőszárító gyorsvezérlő"><div class="dry-grid"><div class="dry-left"><div class="p-title"><span class="pictogram">${zicoIcon("towel")}</span><h2>Törölközőszárító</h2></div><div class="energy">
 ${energyRow("lightning","Aktuális fogyasztás",fmt(power===null?null:Math.round(power),0)+" W",power===null||rate===null?"—":("≈ "+cents(power*rate/1000)+"/h"))}
 ${energyRow("cycle",on?"Aktuális ciklus":relay==="off"?"Utolsó ciklus":this._cycleWhSnapshot?.frozen?"Utolsó ciklus":"Ciklus · nincs kapcsolat",fmt(cycleWh,0)+" Wh",cycleCost===null?"—":"≈ "+cents(cycleCost))}
 ${energyRow("calendar","Fordulónap óta"+(this._billingPartial?" · részleges":""),fmt(bill,3)+" kWh",billCost===null?"—":"≈ "+cents(billCost))}
 </div></div><div class="timerbox towel-fast-controls">
 <div class="towel-manual"><span class="towel-manual-label">KÉZI KAPCSOLÁS</span><div class="towel-manual-buttons"><button type="button" data-act="towel-manual-on" class="towel-manual-on ${on?"selected":""}" ${canOn?"":'disabled title="A konnektor vagy mérés nem elérhető"'} aria-label="Törölközőszárító BE időzítő nélkül">${zicoIcon("power")} BE</button><button type="button" data-act="towel-manual-off" class="towel-manual-off ${!on?"selected":""}" ${canOff?"":"disabled"} aria-label="Törölközőszárító KI">${zicoIcon("stop")} KI</button></div></div>
 <div class="towel-run-state ${stateClass}" role="status" title="${esc(stateText)}"><i class="towel-state-led"></i><span class="towel-proof-text">${esc(stateText)}</span></div>${manualInfo?`<div class="towel-manual-hint" role="status">${esc(manualInfo)}</div>`:""}
 <div class="towel-countdown"><div class="towel-timer-heading">${zicoIcon("timer")}<strong>VISSZASZÁMLÁLÓ</strong><small>${active?"Fut":paused?"Szünetel":"Beállítás"}</small></div>
 <div class="timer-display"><button type="button" class="small-round" data-act="min-minus" aria-label="Időtartam mínusz 15 perc">−</button><div class="timer-time"><div class="timer-text" id="timer-clock">${hhmmss(remaining)}</div><div class="timer-caption"><span>óra</span><span>perc</span><span>mp</span></div></div><button type="button" class="small-round" data-act="min-plus" aria-label="Időtartam plusz 15 perc">+</button></div>
 <div class="timer-presets"><button data-act="preset" data-min="15">15 p</button><button data-act="preset" data-min="30">30 p</button><button data-act="preset" data-min="60">1 ó</button><button data-act="preset" data-min="120">2 ó</button></div>
 <div class="towel-count-actions"><button type="button" class="towel-count-start" data-act="towel-start" ${canTimed?"":'disabled title="Az időzítő biztonsági automatizmusai nem elérhetők"'}>${zicoIcon("play")} ${active?"Újraindítás":"Időzített indítás"}</button><button type="button" class="towel-count-stop" data-act="towel-stop" ${canOff?"":"disabled"}>${zicoIcon("stop")} Leállítás</button></div></div></div></div></section>`;
}
 _timerSecs(){
  const e=this._st(E.dryer.timer);
  if(e?.state!=="active")return this._minutes*60;
  const dt=e.attributes?.finishes_at;
  if(dt){const d=Date.parse(dt);if(Number.isFinite(d))return Math.max(0,(d-Date.now())/1000)}
  return elapsedSecs(e.attributes?.remaining)||0
 }

 _doorSeconds(){
  const timer=this._st("timer.haziko_kulcs_belepesi_idoablak");
  if(timer?.state!=="active")return null;
  const finish=Date.parse(timer.attributes?.finishes_at||"");
  if(!Number.isFinite(finish))return null;
  return Math.max(0,Math.min(60,Math.ceil((finish-Date.now())/1000)));
 }
 _bindEntryEvents(root){
  root.addEventListener("pointerdown",e=>{
   const button=e.target.closest?.('[data-act="entry-hold"]');
   if(!button||button.disabled||this._entryPress||e.isPrimary===false||e.button!==0)return;
   e.preventDefault();
   this._entryPress={id:e.pointerId,x:e.clientX,y:e.clientY,button,long:false};
   button.classList.add("is-pressing");
   try{button.setPointerCapture?.(e.pointerId)}catch(_){}
   this._entryHoldTimer=setTimeout(()=>{
    const p=this._entryPress;
    if(!p||p.id!==e.pointerId)return;
    p.long=true;p.button.classList.remove("is-pressing");
    this._entryAction("unlock");
   },750);
  });
  root.addEventListener("pointermove",e=>{
   const p=this._entryPress;if(!p||p.id!==e.pointerId)return;
   if(Math.hypot(e.clientX-p.x,e.clientY-p.y)>24)this._entryEnd(null,true);
  });
  root.addEventListener("pointerup",e=>{
   const p=this._entryPress;if(!p||p.id!==e.pointerId)return;
   const wasLong=p.long;
   this._entryEnd(e,false);
   if(!wasLong)this._entryAction("lock");
  });
  root.addEventListener("pointercancel",e=>this._entryEnd(e,true));
  root.addEventListener("contextmenu",e=>{if(e.target.closest?.(".kiosk"))e.preventDefault()});
 }
 _entryEnd(e,cancel){
  const p=this._entryPress;
  if(!p||(e&&e.pointerId!==p.id))return;
  clearTimeout(this._entryHoldTimer);this._entryHoldTimer=null;
  p.button.classList.remove("is-pressing");
  try{if(p.button.hasPointerCapture?.(p.id))p.button.releasePointerCapture(p.id)}catch(_){}
  this._entryPress=null;
 }
 async _entryAction(action){
  const door=this._st("binary_sensor.ewelink_snzb_04p_contact")?.state;
  const lock=this._st("lock.eloszoba_bejarati_ajto_also_zar")?.state;
  if(this._entryBusy||!this._online()){this._feedback("Zárvezérlés: nincs elérhető kapcsolat.",true);return}
  if(door!=="off"){this._feedback(door==="on"?"Az ajtó NYITVA: zárás tiltva.":"Ajtóérzékelő állapota ismeretlen: nincs zárvezérlés.",true);return}
  if(action==="unlock"){
   if(lock!=="locked"){this._feedback("Nyitás csak igazoltan zárt U200-ról lehetséges.",true);return}
   const guard=this._st("automation.haziko_kulcs_belepes_ajtofigyeles_es_automatikus_visszazaras")?.state;
   const timer=this._st("timer.haziko_kulcs_belepesi_idoablak")?.state;
   if(guard!=="on"||!timer||["unknown","unavailable"].includes(timer)){this._feedback("A 60 mp-es visszazárási védelem nem elérhető: nyitás tiltva.",true);return}
  }else if(action==="lock"){
   if(lock==="locked"){this._feedback("A bejárati ajtó már zárva van.");return}
   if(lock!=="unlocked"){this._feedback("MOZGÁSBAN vagy ismeretlen zárállapot: nem indítok új parancsot.",true);return}
  }else return;
  this._entryBusy=true;this._render();
  try{
   await this._hass.callService("lock",action==="unlock"?"unlock":"lock",{entity_id:"lock.eloszoba_bejarati_ajto_also_zar"});
   this._feedback(action==="unlock"?"Nyitási parancs elküldve. A valódi U200-állapot és a 60 mp-es időzítő megjelenik.":"Zárási parancs elküldve. Várakozás az U200 visszaigazolására.");
  }catch(err){this._feedback("U200 parancshiba: "+String(err?.message||err).slice(0,100),true)}
  finally{this._entryBusy=false;this._render()}
 }

 _security(){
  const groups=[
   {name:"Nagyszoba",items:[["Kis ablak","binary_sensor.nagyszoba_kis_ablak_ajto"],["Nagy ablak","binary_sensor.nagyszoba_nagyszoba_nagy_ablak_ajto"],["Erkélyajtó","binary_sensor.ewelink_snzb_04p_contact_2"]]},
   {name:"Nappali",items:[["Bal kis ablak","binary_sensor.nappali_nappali_kis_ablak_bal_ajto_2"],["Nagy ablak","binary_sensor.myggbett_door_window_sensor_ajto"],["Jobb kis ablak","binary_sensor.nappali_jobb_kis_ablak_ajto"]]}
  ];
  const contact=id=>this._st(id)?.state||"unavailable";
  const all=groups.flatMap(g=>g.items.map(x=>contact(x[1])));
  const opened=all.filter(s=>s==="on").length,unknown=all.filter(s=>s!=="on"&&s!=="off").length;
  const sum=[opened?opened+" nyitva":"",unknown?unknown+" ismeretlen":"",!opened&&!unknown?"Mind zárva":""].filter(Boolean).join(" · ");
  const opening=(label,id)=>{
   const v=contact(id),tone=v==="off"?"ok":v==="on"?"warn":"unknown",value=v==="off"?"Zárva":v==="on"?"Nyitva":"Nincs adat";
   return `<div class="opening-tile ${tone}" role="status" aria-label="${esc(label+" "+value)}"><span class="opening-label" title="${esc(label)}">${esc(label)}</span><strong>${esc(value)}</strong><i class="opening-led" aria-hidden="true"></i></div>`;
  };
  const groupHtml=groups.map(g=>`<div class="openings-group" role="group" aria-label="${esc(g.name)}"><span class="openings-room-name">${esc(g.name)}</span><div class="openings-row">${g.items.map(i=>opening(i[0],i[1])).join("")}</div></div>`).join("");
  const door=contact("binary_sensor.ewelink_snzb_04p_contact"),lock=contact("lock.eloszoba_bejarati_ajto_also_zar");
  const doorText=door==="off"?"Csukva":door==="on"?"Nyitva":"Ismeretlen";
  const lockText=lock==="locked"?"Zárva":lock==="unlocked"?"Nyitva":lock==="jammed"?"Elakadt":lock==="locking"||lock==="unlocking"?"Mozgásban":"Nincs adat";
  const timer=this._st("timer.haziko_kulcs_belepesi_idoablak");
  const phase=this._st("input_select.haziko_kulcs_belepesi_folyamat")?.state;
  const timerReady=door==="off"&&lock==="unlocked"&&phase==="varakozas_ajtonyitasra"&&timer?.state==="active";
  const seconds=timerReady?this._doorSeconds():null;
  const waiting=seconds!==null;
  const moving=lock==="locking"||lock==="unlocking";
  const tone=door==="on"?"danger":moving?"moving":lock==="unlocked"?"warn":door==="off"&&lock==="locked"?"ok":lock==="jammed"?"danger":"unknown";
  const main=door==="on"?"AJTÓ NYITVA":moving?"MOZGÁSBAN":lock==="unlocked"?"ZÁR NYITVA":door==="off"&&lock==="locked"?"BIZTONSÁGBAN":lock==="jammed"?"ZÁRHIBA":"NINCS ADAT";
  const canHold=door==="off"&&lock==="locked"&&this._online()&&this._st("automation.haziko_kulcs_belepes_ajtofigyeles_es_automatikus_visszazaras")?.state==="on"&&timer&&timer.state!=="unavailable"&&timer.state!=="unknown";
  const canShort=door==="off"&&lock==="unlocked"&&this._online();
  const enable=canHold||canShort;
  const entranceIcon=`<svg viewBox="0 0 36 36" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 32V4h22v28M12 7v22M25 19h-1"/><path d="M13 32h18"/></svg>`;
  const countdown=waiting?`<div class="entry-count" aria-label="Automatikus visszazárás ${seconds} másodperc múlva"><svg class="entry-count-ring" viewBox="0 0 100 100" aria-hidden="true"><circle class="track" cx="50" cy="50" r="40"/><circle class="remaining" cx="50" cy="50" r="40" stroke-dasharray="251.327" stroke-dashoffset="${(251.327*(1-seconds/60)).toFixed(2)}"/></svg><span id="entry-count-seconds">${seconds} mp</span></div>`:"";
  const hint=waiting?"Visszazárás az első ajtónyitásig":door==="on"?"Ajtó nyitva · visszazárás csak becsukás után":moving?"A zárszerkezet állapotváltozása folyamatban":lock==="locked"?"Rövid: már zárva · hosszú: nyitás":lock==="unlocked"?"Rövid: zárás · hosszú: csak zárt állapotból":"Zárvezérlés az ismeretlen állapot miatt tiltva";
  return `<div class="security-status sec-v123" role="group" aria-label="Nyílászárók és bejárati ajtó állapotai"><div class="openings-wrap" role="group" aria-label="Hat nyílászáró"><div class="openings-top"><strong>NYÍLÁSZÁRÓK</strong><span>${esc(sum)}</span></div>${groupHtml}</div><button type="button" class="entry-card entry-interactive ${tone}" data-act="entry-hold" aria-label="Bejárati ajtó: ${esc(main)}, ajtó ${esc(doorText)}, zár ${esc(lockText)}. Rövid nyomás zár, hosszú nyomás nyit." ${enable?"":'disabled title="Az ajtó vagy a zár nem vezérelhető ebben az állapotban"'}><span class="entry-title">BEJÁRATI AJTÓ</span><span class="entry-main"><span class="entry-icon">${entranceIcon}</span><strong>${esc(main)}</strong>${countdown}</span><span class="entry-states"><span><span>AJTÓ</span><strong>${esc(doorText)}</strong></span><span><span>U200 ZÁR</span><strong>${esc(lockText)}</strong></span></span><span class="entry-hint">${esc(hint)}</span><span class="entry-press-progress" aria-hidden="true"></span></button></div>`;
 }
 _airRemember(level){
  const n=Number(level);
  if(!Number.isFinite(n)||n<0||n>14)return;
  this._airManualLevel=Math.round(n);
  try{localStorage.setItem(this._airStorageKey,String(this._airManualLevel))}catch(_){}
 }
 _airPreset(){
  const mode=this._st(E.air.mode)?.state;
  const raw=this._airTelemetry.manual!==null?this._airTelemetry.manual:this._n(E.air.manual);
  const valid=raw!==null&&raw>=0&&raw<=14;
  if(this._airManualPending!==null){
   if(valid&&Math.round(raw)===this._airManualPending){this._airManualPending=null;this._airRemember(raw)}
   else return this._airManualLevel??this._airManualPending;
  }
  if(mode==="Manual"&&this._st(E.air.power)?.state==="on"&&valid){this._airRemember(raw);return Math.round(raw)}
  if(this._airManualLevel!==null)return this._airManualLevel;
  if(valid){this._airRemember(raw);return Math.round(raw)}
  return null;
 }
 async _airRefresh(){
  const hass=this._hass;
  if(!this.isConnected||this._airPolling||!this._online()||typeof hass?.callApi!=="function")return;
  this._airPollAt=Date.now();this._airPolling=true;
  try{
   const results=await Promise.allSettled([E.air.rpm,E.air.manual].map(id=>hass.callApi("GET","states/"+encodeURIComponent(id))));
   if(!this.isConnected)return;
   for(let i=0;i<results.length;i++){
    if(results[i].status!=="fulfilled")continue;
    const value=finite(results[i].value?.state);
    if(i===0)this._airTelemetry.rpm=value;
    if(i===1)this._airTelemetry.manual=value;
   }
   this._airUpdateDom();
  }finally{this._airPolling=false}
 }
 _airUpdateDom(){
  if(!this.isConnected)return;
  const rpm=this._airTelemetry.rpm;
  const rpmNode=this._container.querySelector("[data-air-rpm]");
  if(rpmNode)rpmNode.innerHTML=fmt(rpm,0)+" <small>rpm</small>";
  const preset=this._airPreset();
  const percent=preset===null?null:Math.round(preset/14*100);
  const pctNode=this._container.querySelector("[data-air-manual-percent]");
  if(pctNode)pctNode.textContent=percent===null?"—":percent+" %";
  const slider=this._container.querySelector('input[data-act="manual-level"]');
  if(slider){
   const mode=this._st(E.air.mode)?.state;
   slider.disabled=!["Auto","Manual"].includes(mode)||this._st(E.air.power)?.state!=="on";
   if(!slider.matches(":active"))slider.value=String(preset??0);
   slider.style.setProperty("--fill",(percent??0)+"%");
  }
 }
 _air(){
 const A=E.air,on=this._st(A.power)?.state==="on",option=this._st(A.mode)?.state||"unknown",manual=this._airPreset(),rpm=this._airTelemetry.rpm!==null?this._airTelemetry.rpm:this._n(A.rpm),pm=this._n(A.pm),ct=this._n(A.temp),hum=this._n(A.hum),filter=this._n(A.filter);
 const mode=on?option:"Off";
 const modes=[["Auto","Auto"],["Sleep","Éjszakai"],["Manual","Manual"],["Off","Off"]];
 const percent=manual===null?null:Math.round(Math.max(0,Math.min(14,manual))/14*100);
 const airTile=(ico,label,val,unit,extra="")=>`<div class="air-tile"><span class="air-ico ${extra}">${zicoIcon(ico)}</span><span class="k">${label}</span><div class="v">${val}${unit?` <small>${unit}</small>`:""}</div></div>`;
 return `<section class="panel air ${mode==="Auto"?"air-mode-auto":""}" aria-label="Légminőség"><div class="air-head"><div class="p-title"><span class="pictogram">${zicoIcon("wind")}</span><h2>Légminőség</h2></div>
 <div class="mode-group">${modes.map(([m,title])=>`<button data-act="air-mode" data-mode="${m}" class="${mode===m?"selected":""}">${title}</button>`).join("")}</div></div>
 <div class="air-rpm"><span class="rpm-ico">${zicoIcon("fan")}</span><div class="rpm-text"><div class="rpm-sub">Fordulatszám</div><div class="rpm-value" data-air-rpm>${fmt(rpm,0)} <small>rpm</small></div></div>
 <div class="air-speed"><input aria-label="Kézi teljesítmény-előbeállítás, Auto módban a következő Manual módhoz" title="${mode==="Auto"?"Auto módban előkészítés, nem az aktuális teljesítmény":"Manual teljesítmény"}" type="range" data-act="manual-level" min="0" max="14" step="1" value="${manual??0}" ${mode==="Manual"||mode==="Auto"?"":"disabled"} style="--fill:${percent??0}%"/><strong data-air-manual-percent title="Utolsó kézi beállítás, nem az Auto mód mért teljesítménye">${percent===null?"—":percent+" %"}</strong></div></div>
 <div class="air-metrics">${airTile("pm","PM2.5",fmt(pm,0),"µg/m³")}${airTile("thermo","Hőmérséklet",fmt(ct,0),"°C")}${airTile("drop","Páratartalom",fmt(hum,0),"%")}${airTile("leaf","Szűrő élettartama",fmt(filter,0),"%","leaf-green")}</div>${this._security()}</section>`;
}
 _kioskNav(){
  const sections=[
   {id:"thermostat",name:"Ziko Kiosk Thermostat",icon:"thermo",ready:true},
   {id:"lights",name:"Világítások",icon:"bulb",ready:true},
   {id:"security",name:"Biztonság",icon:"shield",ready:false},
   {id:"media",name:"Média",icon:"media",ready:false}
  ];
  return `<nav class="kiosk-nav" aria-label="Ziko Kiosk oldalak">${sections.map(x=>{const active=x.id==="thermostat";return `<button type="button" class="kiosk-nav-button ${active?"is-active":x.ready?"is-ready":"is-future"}" data-act="kiosk-section" data-section="${x.id}" title="${x.name}${x.ready?"":" – később"}" aria-label="${x.name}${active?" – aktív":x.ready?" – megnyitás":" – előkészítve"}" ${active?'aria-current="page"':""}>${zicoIcon(x.icon)}</button>`}).join("")}</nav>`;
 }
 _render(){
 if(!this._container||!this._hass)return;
 const connected=this._online();
 const content=`<div class="kiosk"><header class="topbar"><div class="brand"><button class="home" data-act="go-home" aria-label="Házikó főoldal">${zicoIcon("house")}</button><h1>Ziko Kiosk</h1></div><div class="clock" id="main-clock">${timeFmt.format(new Date())}</div><div class="ha-wrap">${this._kioskNav()}<button data-act="fullscreen" class="ha-ziko ${connected?"online":"offline"}" aria-label="HA-Ziko teljes képernyő">${zicoIcon("house")}<span>HA-Ziko</span></button></div></header>
 <main class="dashboard">${this._radiator(E.rooms[0],0)}${this._radiator(E.rooms[1],1)}${this._towel()}${this._air()}</main>${this._notice?`<div class="notice ${this._warning?"warn":""}" role="status">${esc(this._notice)}</div>`:""}</div>`;
 this._container.innerHTML=content;
}
 _tick(){
  if(!this.isConnected)return;
  if(Date.now()-this._airPollAt>=5000)this._airRefresh();
  const c=this._container.querySelector("#main-clock");if(c)c.textContent=timeFmt.format(new Date());
  const t=this._container.querySelector("#timer-clock"),active=this._st(E.dryer.timer)?.state==="active";
  if(t&&active)t.textContent=hhmmss(this._timerSecs());
  const entry=this._container.querySelector("#entry-count-seconds");
  if(entry){
   const door=this._st("binary_sensor.ewelink_snzb_04p_contact")?.state,lock=this._st("lock.eloszoba_bejarati_ajto_also_zar")?.state;
   const secs=this._doorSeconds();
   if(door!=="off"||lock!=="unlocked"||secs===null){this._render();return}
   entry.textContent=secs+" mp";
   const ring=this._container.querySelector(".entry-count-ring .remaining");
   if(ring)ring.setAttribute("stroke-dashoffset",(251.327*(1-secs/60)).toFixed(2));
  }
 }
 _feedback(text,warning){
  this._notice=text;this._warning=!!warning;this._render();
  clearTimeout(this._noticeTimeout);this._noticeTimeout=setTimeout(()=>{this._notice="";this._render()},3500)
 }
 async _service(domain,service,data,successText="Parancs elküldve a Házikónak."){
  if(this._busy||!this._online()){this._feedback("Nincs elérhető Házikó-kapcsolat.",true);return}
  this._busy=true;
  try{await this._hass.callService(domain,service,data);this._feedback(successText)}catch(e){this._feedback("Vezérlési hiba: "+String(e?.message||e).slice(0,110),true)}finally{this._busy=false}
 }
 async _click(e){
 const b=e.target.closest("button[data-act]");if(!b||!this._hass||b.disabled)return;
 if(b.dataset.act==="entry-hold"){if(e.detail===0)await this._entryAction("lock");return}
 const act=b.dataset.act,room=E.rooms[Number(b.dataset.room)];
 if(act==="kiosk-section"){
  const section=b.dataset.section;
  const title={thermostat:"Ziko Kiosk Thermostat",lights:"Világítások",security:"Biztonság",media:"Média"}[section];
  if(section==="lights"){kioskSpaNavigate("/ziko-kiosk-thermostat/vilagitasok");return}
  if(!title)return;
  this._feedback(section==="thermostat"?"A Ziko Kiosk Thermostat oldal aktív.":title+" – a menüpont előkészítve, az oldal később készül el.");
  return;
 }
 if(act==="go-home"){location.href="/haziko-kozpont/attekintes";return}
 if(act==="go-climate"){location.href="/haziko-kozpont/klima-3";return}
 if(act==="rad-menu"){this._feedback("Radiátor: "+E.rooms[Number(b.dataset.room)]?.name);return}
 if(act==="fullscreen"){try{if(document.fullscreenElement)await document.exitFullscreen();else await (this._overlay||this).requestFullscreen()}catch(err){this._feedback("A teljes képernyő nem engedélyezett.",true)}return}
 if(act==="target-minus"||act==="target-plus"){if(!room)return;const x=this._tempRoom(room),delta=act==="target-plus"?.5:-.5;if(x.target===null){this._feedback("Nem ismert a célhőmérséklet.",true);return}return this._service("climate","set_temperature",{entity_id:room.climate,temperature:Math.min(35,Math.max(4,Math.round((x.target+delta)*2)/2))})}
 if(act==="hvac"&&room)return this._service("climate","set_hvac_mode",{entity_id:room.climate,hvac_mode:b.dataset.mode});
 if(act==="min-minus"||act==="min-plus"){this._minutes=Math.max(5,Math.min(720,this._minutes+(act==="min-plus"?15:-15)));this._render();return}
 if(act==="preset"){const n=Number(b.dataset.min);if([15,30,60,120].includes(n)){this._minutes=n;this._render()}return}
 if(["towel-manual-on","towel-manual-off","towel-start","towel-stop"].includes(act)){
  const T=E.dryer,relay=this._st(T.relay)?.state,power=this._n(T.power),timer=this._st(T.timer)?.state;
  if(this._busy||!this._online()){this._feedback("Nincs elérhető vezérlőkapcsolat.",true);return}
  if(["towel-manual-on","towel-start"].includes(act)&&(!["on","off"].includes(relay)||power===null||power<0||power>=3000)){this._feedback("Konnektor vagy mérés nem elérhető. Bekapcsolás tiltva.",true);return}
  if(act==="towel-start"){
   if(this._st("automation.torolkozoszarito_idozitett_inditas")?.state!=="on"||this._st("automation.torolkozoszarito_idozito_lejart")?.state!=="on"||!["idle","active","paused"].includes(timer)){this._feedback("Az időzítő biztonsági automatizmusai nem elérhetők.",true);return}
   return this._service("timer","start",{entity_id:T.timer,duration:hhmmss(this._minutes*60)},"Időzítő elindítása elküldve. A fizikai fűtést a fogyasztásmérésnek kell igazolnia.");
  }
  this._busy=true;
  try{
   if(act==="towel-manual-on"){
    if(timer==="active"||timer==="paused")await this._hass.callService("timer","cancel",{entity_id:T.timer});
    if(relay==="off"){
     const baseline=this._n(T.energy);
     if(baseline!==null&&baseline>=0)await this._hass.callService("input_number","set_value",{entity_id:T.start,value:baseline});
     await this._hass.callService("switch","turn_on",{entity_id:T.relay});
    }
    this._feedback("Kézi BE elküldve. Nincs automatikus kikapcsolás; élő állapot ellenőrzendő.");
   }else{
    const outcome=await Promise.allSettled([this._hass.callService("timer","cancel",{entity_id:T.timer}),this._hass.callService("switch","turn_off",{entity_id:T.relay})]);
    const failed=outcome.filter(x=>x.status==="rejected");
    this._feedback(failed.length?"Leállítás részben sikertelen: az állapot ellenőrizendő!":"KI és időzítőtörlés elküldve; az élő állapot jelzi a végeredményt.",!!failed.length);
   }
  }catch(err){this._feedback("Törölközőszárító vezérlési hiba: "+String(err?.message||err).slice(0,115),true)}finally{this._busy=false;this._render()}
  return;
 }
 if(act==="air-mode"){
  const mode=b.dataset.mode,air=E.air;
  if(!["Auto","Sleep","Manual","Off"].includes(mode))return;
  if(this._busy||!this._online())return;
  this._busy=true;
  const preset=mode==="Manual"?this._airPreset():null;
  if(mode==="Manual"&&preset!==null)this._airManualPending=preset;
  try{
   if(mode==="Off")await this._hass.callService("switch","turn_off",{entity_id:air.power});
   else{
    await this._hass.callService("switch","turn_on",{entity_id:air.power});
    await this._hass.callService("select","select_option",{entity_id:air.mode,option:mode});
    if(mode==="Manual"&&preset!==null)await this._hass.callService("number","set_value",{entity_id:air.manual,value:preset});
   }
   this._feedback(mode==="Manual"&&preset!==null?"Manual: "+Math.round(preset/14*100)+" % előbeállítás elküldve.":"Üzemmódparancs elküldve.");
  }catch(err){if(mode==="Manual")this._airManualPending=null;this._feedback("Légtisztító vezérlési hiba: "+String(err?.message||err).slice(0,100),true)}finally{this._busy=false}
 }
}
 _change(e){
  if(e.target.matches('input[data-act="manual-level"]')){
   const v=Math.max(0,Math.min(14,Math.round(Number(e.target.value))));
   const mode=this._st(E.air.mode)?.state;
   if(!["Auto","Manual"].includes(mode))return;
   if(mode==="Manual"&&(this._busy||!this._online())){this._feedback("A kézi teljesítmény most nem állítható.",true);return}
   this._airRemember(v);
   if(mode==="Manual"){
    this._airManualPending=v;
    this._service("number","set_value",{entity_id:E.air.manual,value:v});
   }
   this._airUpdateDom();
  }
 }
 _historyUrl(iso,ids,noAttr){
  return "history/period/"+encodeURIComponent(iso)+"?filter_entity_id="+encodeURIComponent(ids.join(","))+"&minimal_response=1"+(noAttr?"&no_attributes=1":"")
 }
 async _loadHistory(){
  const hass=this._hass;if(!hass||typeof hass.callApi!=="function")return;
  this._historyAt=Date.now();
  const end=Date.now(),start=end-6*3600*1000;
  await Promise.all(E.rooms.map(async room=>{
   const ids=[room.climate,room.rad,room.temp,room.hum];
   try{
    const data=await hass.callApi("GET",this._historyUrl(new Date(start).toISOString(),ids,false));
    if(!Array.isArray(data))throw Error("history unavailable");
    const groups=new Map();
    for(const arr of data){if(Array.isArray(arr)&&arr.length)groups.set(arr[0].entity_id,arr)}
    const series=ids.map((id,i)=>{
     const entries=groups.get(id)||[];
     return entries.map(x=>({t:Date.parse(x.last_changed||x.last_updated),v:finite(i===0?x.attributes?.temperature:x.state)})).filter(p=>Number.isFinite(p.t)&&p.v!==null&&p.t>=start-120000).map(p=>({t:p.t,v:p.v}));
    });
    this._history[room.name]={series,start,end};
   }catch(e){this._history[room.name]={error:true}}
  }));
  this._render()
 }
 async _loadBilling(){
  const hass=this._hass;if(!hass||typeof hass.callWS!=="function")return;
  this._billingAt=Date.now();
  const day=Math.max(1,Math.min(31,Math.round(this._n(E.dryer.billing)||1)));
  const now=new Date();
  const maxDay=(y,m)=>new Date(y,m+1,0).getDate();
  let base=new Date(now.getFullYear(),now.getMonth(),Math.min(day,maxDay(now.getFullYear(),now.getMonth())),0,0,0);
  if(base>now)base=new Date(now.getFullYear(),now.getMonth()-1,Math.min(day,maxDay(now.getFullYear(),now.getMonth()-1)),0,0,0);
  try{
   const data=await hass.callWS({type:"recorder/statistics_during_period",start_time:base.toISOString(),end_time:now.toISOString(),statistic_ids:[E.dryer.energy],period:"hour",types:["sum"]});
   const records=Array.isArray(data?.[E.dryer.energy])?data[E.dryer.energy]:[];
   const readings=records.map(x=>({t:finite(x.start),sum:finite(x.sum)})).filter(x=>x.sum!==null&&x.t!==null).sort((a,b)=>a.t-b.t);
   if(readings.length>=2&&readings[0].t<=base.getTime()+3600000){
    this._billingUsage=Math.max(0,readings[readings.length-1].sum-readings[0].sum);
    this._billingPartial=readings[0].t>base.getTime()+15*60000;
   }else{this._billingUsage=null;this._billingPartial=false}
  }catch(e){this._billingUsage=null;this._billingPartial=false}
  this._render()

 }
}
if(!customElements.get("ziko-kiosk-thermostat"))customElements.define("ziko-kiosk-thermostat",ZikoKioskThermostat);
window.customCards=window.customCards||[];
if(!window.customCards.some(x=>x.type==="ziko-kiosk-thermostat"))window.customCards.push({type:"ziko-kiosk-thermostat",name:"ZIKO Kiosk Thermostat",description:"Valós Házikó Klíma/Node03 termosztát kártya"});
})();
